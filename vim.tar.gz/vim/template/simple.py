#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
This is a python code template
"""

import os


def test():
    os.system('echo Hello World')



if __name__ == '__main__':
    test()

